﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace LojaCL
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void btnCadastro_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = Conexao.obterConexao();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandText = "InserirCartaoVenda";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@numero", txtnumero.Text);
                cmd.Parameters.AddWithValue("@usuario", txtusuario.Text);             
                Conexao.obterConexao();
                cmd.ExecuteNonQuery();
                //CarregaDgvCartaoVenda();
                FrmPrincipal obj = (FrmPrincipal)Application.OpenForms["FmrPrincipal"];
                obj.CarregadataGridView1();
                MessageBox.Show("Registro inserido com sucesso!", "Cadastro", MessageBoxButtons.OK);
                Conexao.fecharConexao();
                txtnumero.Text = "";
                txtusuario.Text = "";
               



            }
            catch (Exception er)
            {
                MessageBox.Show(er.Message);
            }
        }

        private void btnEditar_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = Conexao.obterConexao();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandText = "InserirCartaoVenda";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@numero", txtnumero.Text);
                cmd.Parameters.AddWithValue("@usuario", txtusuario.Text);
                Conexao.obterConexao();
                cmd.ExecuteNonQuery();
                //CarregaDgvCartaoVenda();
                FrmPrincipal obj = (FrmPrincipal)Application.OpenForms["FmrPrincipal"];
                obj.CarregadataGridView1();
                MessageBox.Show("Registro inserido com sucesso!", "Cadastro", MessageBoxButtons.OK);
                Conexao.fecharConexao();
                txtnumero.Text = "";
                txtusuario.Text = "";


            }
            catch (Exception er)
            {

                MessageBox.Show(er.Message);
            }
        }

        private void btnExcluir_Click(object sender, EventArgs e)
        {
            try
            {
                SqlConnection con = Conexao.obterConexao();
                SqlCommand cmd = con.CreateCommand();
                cmd.CommandText = "InserirCartaoVenda";
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.Parameters.AddWithValue("@numero", txtnumero.Text);
                cmd.Parameters.AddWithValue("@usuario", txtusuario.Text);
                Conexao.obterConexao();
                cmd.ExecuteNonQuery();
                //CarregaDgvCartaoVenda();
                FrmPrincipal obj = (FrmPrincipal)Application.OpenForms["FmrPrincipal"];
                obj.CarregadataGridView1();
                MessageBox.Show("Registro inserido com sucesso!", "Cadastro", MessageBoxButtons.OK);
                Conexao.fecharConexao();
                txtnumero.Text = "";
                txtusuario.Text = "";


            }
            catch (Exception er)
            {

                MessageBox.Show(er.Message);
            }
        }
    }
}
